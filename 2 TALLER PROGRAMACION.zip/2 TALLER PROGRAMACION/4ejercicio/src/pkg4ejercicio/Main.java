/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg4ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner teclado= new Scanner(System.in);
         
        int numero1 = 0;
        int numero2 = 0;
  
        System.out.println("Introduce el primer número:");      
        numero1 = teclado.nextInt();
      
        System.out.println("Introduce el segundo número:");
        numero2 = teclado.nextInt();
        
        int resultado = numero1+numero2;
        System.out.println("La suma es " + numero1 + " + " + numero2 + " = " + resultado);
        
        resultado = numero1-numero2;
        System.out.println("La resta es " + numero1 + " - " + numero2 + " = " + resultado);
       
        resultado = numero1/numero2;
        System.out.println("La Division " + numero1 + " / " + numero2 + " = " + resultado);
        
        resultado = numero1*numero2;
        System.out.println("La multiplicacion " + numero1 + " / " + numero2 + " = " + resultado);
    }
    
}
