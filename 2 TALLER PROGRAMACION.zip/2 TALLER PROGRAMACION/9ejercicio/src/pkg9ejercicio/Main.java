/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg9ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       Scanner teclado = new Scanner (System.in);
       
       float total;
       float descuento;
       
       System.out.println("INGRESE EL TOTAL DE SU COMPRA");
       total = teclado.nextFloat();
       descuento = total * .15f;
       System.out.println("SU DESCUENTO APLICADO ES: $" + descuento);
       System.out.println("TOTAL A PAGAR ES: $" + (total-descuento));
       teclado.close();
       
       
       
       
    }
    
}
