/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg20ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        
        Scanner teclado= new Scanner(System.in);
        
        int monedas10;
        int monedas20;
        int monedas2;
        int monedas1;
        int monedas50;
        
        System.out.print("Monedas de 2 euros: ");
        monedas2 = teclado.nextInt();
        
        System.out.print("Monedas de 1 euro: ");
        monedas1 = teclado.nextInt();
        System.out.print("Monedas de 50 céntimos: ");
        monedas50 = teclado.nextInt();
        System.out.print("Monedas de 20 céntimos: ");
        monedas20 = teclado.nextInt();
        System.out.print("Monedas de 10 céntimos: ");
        monedas10 = teclado.nextInt();

      
        int totalCents = monedas2 * 200 + monedas1 * 100 + monedas50 * 50 + monedas20 * 20 + monedas10 * 10;
        int euros = totalCents / 100;
        int centimos = totalCents % 100;

       
        System.out.println("SU TOTAL DE DINERO ES: " + euros + " EUROS Y " + centimos + " CENTIMOS");
    }
    
}
