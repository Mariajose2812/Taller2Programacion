/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg3ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Main {
   

    public static void main(String[] args) {
        
    
          Scanner teclado= new Scanner(System.in);
          
     double catetol, cateto2, hipotenusa; 
     
     catetol=numeroreal("NUMERO DEL PRIMER CATETO: ");
     cateto2= numeroreal("NUMERO DEL SEGUNDO CATETO: ");
     
     hipotenusa=Math.sqrt(Math.pow(catetol, 2)+ Math.pow (catetol, 2));
     
     System.out.printf("%nLA HIPOTENUSA ES %.2f.", hipotenusa);
     
    }
     private static double numeroreal (String s) { 
        Scanner Sc = new Scanner(System.in);
         System.out.print(s);
         return Sc.nextDouble();
    }
    
}
