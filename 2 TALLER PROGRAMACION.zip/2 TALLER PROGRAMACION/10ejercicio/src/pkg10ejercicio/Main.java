/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg10ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        float promedio;
        float calificacion1;
        float calificacion2; 
        float calificacion3;
        float examen;
        float trabajo;
        float promediofinal;
        
        System.out.println("INGRESE SUS TRES NOTAS");
        calificacion1= teclado.nextFloat();
        calificacion2=teclado.nextFloat();
        calificacion3= teclado.nextFloat();
        
        promedio= (calificacion1+calificacion2+calificacion3)/ 3;
        
        System.out.println("INGRESE LA NOTA DEL EXAMEN FINAL");
        examen= teclado.nextFloat();
        
        System.out.println("INGRESE LA NOTA DEL TRABAJO FINAL");
        trabajo=teclado.nextFloat();
        
        promediofinal=(promedio * .55f)+ (examen * .30f) + (trabajo * .15f);
        
        System.out.println("SU PROMEDIO FINAL ES:" + promediofinal);
        teclado.close();
        
        
        
    }
    
}
