/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg18ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      Scanner teclado = new Scanner(System.in);
        
    String nombre;
    String apellido1;
    String apellido2;
    String iniciales;
    
        System.out.print("NOMBRE:");
        nombre = teclado.next();
        System.out.print("PRIMER APELLIDO: ");
        apellido1 = teclado.next();
        System.out.print("SEGUNDO APELLIDO");
        apellido2 = teclado.next();

     
        char inicialNombre = nombre.charAt(0);
        char inicialApellido1 = apellido1.charAt(0);
        char inicialApellido2 = apellido2.charAt(0);

        // mostrar las iniciales
        System.out.println("LAS INICIALES DE SU NOMBRE SON: " + inicialNombre + inicialApellido1 + inicialApellido2);
    }
}

    

