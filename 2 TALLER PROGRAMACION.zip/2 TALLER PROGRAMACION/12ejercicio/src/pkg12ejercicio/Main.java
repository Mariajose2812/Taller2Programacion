/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg12ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
    
    double distancia;   
    int x1;
    int y1;
    int x2;
    int y2;
    
    
    System.out.print("ECRIBA EL VALOR DE X DEL 1 PUNTO : ");
    x1 = teclado.nextInt();
    System.out.print("ECRIBA EL VALOR DE Y DEL 1 PUNTO: ");
    y1 = teclado.nextInt();
    System.out.print ("ESCRIBA EL VALOR DE X DEL 2 PUNTO:");
    x2 = teclado.nextInt();
    System.out.print ("ESCRIBA EL VALOR DE Y DEL 2 PUNTO: ");
    y2 = teclado.nextInt();
    

    distancia = Math.sqrt (Math.pow ((x2-x1),2) + Math.pow ((y2-y1),2));

    System.out.println("LA DISTANCIA ENTRE LOS DOS PUNTOS ES:" +distancia);
    
  }
}
    
    

