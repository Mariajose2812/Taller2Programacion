/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg2ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner; 
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner teclado= new Scanner(System.in);
        
        double altura, area, base, perimetro;
        
        System.out.print("Ingresa el valor de altura: ");
        altura = teclado.nextDouble();
        teclado.nextLine();
        
        System.out.print("Ingresa el valor de base: ");
        base = teclado.nextDouble();
        teclado.nextLine();
        
        area=altura*base;
        perimetro=altura+base+altura+base;
        
        System.out.println("Valor de area: " + area); 
        System.out.println("Valor de perimetro: " + perimetro);
}
    }
    
