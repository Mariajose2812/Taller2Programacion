/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg7ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        
        System.out.print("Ingresa la cantidad de minutos: ");
        int minutos = teclado.nextInt();
        teclado.close();
        
        int horas = minutos / 60;
        int minutosRestantes = minutos % 60;
        
        System.out.printf("%d minutos son: %d horas y %d minutos.", minutos, horas, minutosRestantes);
    }
    
}
