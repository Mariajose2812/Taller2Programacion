/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg16ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner scanner = new Scanner (System.in);
    
    double tiempo;
    double desigualdadVelocidad;
    double distancia;
    double vehiculo1;
    double vehiculo2;
  
   
    System.out.print("ESCRIBA LA VELOCIDAD A LA QUE SE ENCUTRAN LOS DOS VEHICULOS ");
    distancia = scanner.nextDouble();
    System.out.print("VELOCIDAD EN Km/h DEL VEHICULO 1 ES MAS LENTO: ");
    vehiculo1 = scanner.nextDouble();
    System.out.print("VELOCIDAD Km/h DEL VEHICULO 2 ES MAS RAPIDO: ");
    vehiculo2 = scanner.nextDouble();   
    

    desigualdadVelocidad = vehiculo2- vehiculo1;
    tiempo = distancia / (desigualdadVelocidad); 

    tiempo = tiempo * 60;

    System.out.println("AMBOS VEHICULOS COINSIDEN TRANSCURRIDOS" + (int)tiempo + " MINUTOS.");
    
  }
}
    
    

