/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg19ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);
    
    int noContestadas;
    int notaFinal;
    int incorrectas;
    int notaMaxima;
    double notaSobre10;
    int correctas;

    
    System.out.print("TOTAL DE PREGUNTAS CORRECTAS: ");
    correctas = teclado.nextInt();
    
    System.out.print("TOTAL DE PREGUNTAS INCORRECTAS: ");
    incorrectas = teclado.nextInt();
    
    System.out.print ("TOTAL DE PREGUNTAS NO CONTESTADAS: ");
    noContestadas = teclado.nextInt();
    
    notaMaxima = (correctas + incorrectas + noContestadas) * 5;
    notaFinal = (correctas*5) + (incorrectas*(-1));

    notaSobre10 = (double)(notaFinal*10) / notaMaxima;
    
    System.out.printf("NOTA FINAL: " + notaFinal + ", CORRESPONDE A UN: %5.2f SOBRE 10", notaSobre10);
    }
    
}
