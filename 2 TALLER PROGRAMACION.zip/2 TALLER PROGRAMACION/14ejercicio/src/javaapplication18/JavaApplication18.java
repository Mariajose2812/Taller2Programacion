/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication18;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class JavaApplication18 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner(System.in);
    
    System.out.print("INGRESE EL NUMERO QUE DESEA INVERTIR: ");
    String word = teclado.nextLine();

    System.out.print("ESTE ES EL NUMERO INVERTIDO: ");
    for (int m = word.length() - 1; m >= 0; m--) {
      System.out.print(word.charAt(m ));
    }
    System.out.println();
  }
} 
    
    

