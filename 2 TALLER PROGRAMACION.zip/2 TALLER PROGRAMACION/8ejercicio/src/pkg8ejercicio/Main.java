/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg8ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner teclado= new Scanner (System.in);
        
        double salarioBase ;
        double venta1;
        double venta2;
        double venta3;
        double comision;
        double salariototal;
        
        System.out.println("SALARIO BASE");
        salarioBase= teclado.nextDouble();
        System.out.println("GANACIA DE LA VENTA 1");
        venta1 = teclado.nextDouble();
        System.out.println("GANANCIA DE LA VENTA 2");
        venta2 = teclado.nextDouble();
        System.out.println("GANACIA DE LA VENTA 3");
        venta3= teclado.nextDouble();
        
        comision = 0.1*(venta1 + venta2 + venta3);
        
        salariototal= salarioBase + comision;
        
        System.out.println("SALARIO TOTAL QUE DEBE RECIBIR ES" +salariototal + ".\nEQUIVALENTE AL SALARIO BASE:" +salarioBase +"Y COMISIONES:");
        
    }
    
}
