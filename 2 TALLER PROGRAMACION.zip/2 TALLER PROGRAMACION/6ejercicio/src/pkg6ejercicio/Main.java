/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg6ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int sum = 0, inputNum;
    int contador;
    float media;
    
    
    Scanner Numteclado= new Scanner(System.in);
    Scanner charteclado= new Scanner(System.in);
    
System.out.println("Ingrese el total de  numeros");

contador = Numteclado.nextInt();

System.out.println ("Ingrese los" + contador + "numeros:");


for (int x = 1; x<=contador; x++){
        inputNum = Numteclado.nextInt(); 
        sum = sum + inputNum;
        System.out.println();
              
}
media= sum / contador;
System.out.println ("la media de" + contador + "los numeros ingresados es:" + media);
    }
}
    
    

