/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg17ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner teclado = new Scanner (System.in);
    
    int horas;
    int totalSegundos;
    int segundosRestantes;
    int minutos;
    int segundos;
    int tiempo;
  
    System.out.print("ESCRIBA LA HORA SEGMENTADA: ");
    horas = teclado.nextInt();
    System.out.print("ESCRIBA LOS MINUTOS: ");
    minutos = teclado.nextInt();
    System.out.print ("ESCRIBA LOS SEGUNDOS: ");
    segundos = teclado.nextInt();
    System.out.print ("¿CUANTO DURO EL VIAJE EN SEGUNDOS?: ");
    tiempo = teclado.nextInt();
    

    totalSegundos = horas *3600 + minutos*60 + segundos + tiempo;
 
    horas = totalSegundos / 3600;
    segundosRestantes = totalSegundos % 3600;
    minutos = segundosRestantes / 60;
    segundos = segundosRestantes % 60;

    System.out.println("LLEGARA A LA CIUDAD B A LAS: "+ horas +":" + minutos+ ":"+segundos);
    }
    
}
