/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg13ejercicio;

/**
 *
 * @author Maria jose
 */
import java.util.Scanner;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
      Scanner teclado = new Scanner(System.in);

      double numero;
      
      System.out.print("INGRESE UN NUMERO: ");
      numero = teclado.nextDouble();

      double raiz2 = Math.sqrt(numero);
      double raiz3 = Math.cbrt(numero);

      
    System.out.println("LA RAIZ CUBICA DE "+numero + " ES: " + raiz2);
    System.out.println("LA RAIZ CUBICA DE  "+numero + " ES:" + raiz3);
    }
    
}
